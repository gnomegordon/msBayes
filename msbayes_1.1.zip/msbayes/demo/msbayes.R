################################################################
#### The demo show how to use the msbayes package for       ####
#### methylation level estimation                           ####
#### Before you use the package, please install WinBUGS     ####
#### and R package 'R2WinBUGS' and 'BOA'                    ####
################################################################

### loading necessary packages ###
library(msbayes)
library(R2WinBUGS)
library(boa)

### browse the help files ###
help(package="msbayes")

#########################################################################################
### import the methyl-seq data, the data is one region data from Brunner et al (2009) ###
#########################################################################################
 
data(methyl.seq)                                      ### the Brunner et al sample library data 
data(genome.seq.diff.adj)                             ### the Brunner et al sample data sequencing depth bias

seq.dep.bias <- genome.seq.diff.adj$seq.dep.bias      ### the Brunner et al sample data genome-wide sequening depth bias

dat <- methyl.seq[,-c(1,2)];                          ### the first 2 columns are chromosome # and site id
rownames(dat) <- methyl.seq[,2]


################################################################
######## methyl.bayes                                  #########
######## the methylation ratio estimate for one region #########
################################################################

?methyl.bayes                                               ### check the help file
input <- dat
region.est <- methyl.bayes(input,seq.dep.bias,'brunner')    ### the resulted methylation ratio result 


###############################################################
######## methyl.bayes.site                            #########
######## the methylation ratio estimate for each site #########
###############################################################

?methyl.bayes.site                                          ### check the help file
site.est <- matrix(NA,ncol=ncol(dat)-1, nrow=nrow(dat))     ### pre-assign the methylation ratio matrix result 

for (k in 1:nrow(dat)){
data.temp <- dat[k,,drop=FALSE]
input <- as.matrix(data.temp)
feed <- methyl.bayes.site(input,seq.dep.bias,'brunner');
site.est[k,]<-feed[,2];
}

rownames(site.est) <- rownames(methyl.seq)
colnames(site.est) <- colnames(dat)[-1]
site.est                                                    ### the resulted methylation ratio result 

####### plot #############
methyl.bayes.plot(methyl.seq,site.est,region.est)


###############################################################
######## methyl.tpe                                   #########
######## truncated maximum likelihood estimate        #########
###############################################################
?methyl.tpe	                                               ### check the help file

#### site level estimate
site_input <- dat[2,,drop=FALSE]
site_input <- as.matrix(site_input)
site_tpe <- methyl.tpe(site_input)
site_tpe

#### region level estimate
region_input <- as.matrix(dat)
region.est <- methyl.tpe(region_input,seq.dep.bias,'brunner')

##################################################################
##################################################################
#######     apply your own data into analysis,              ######
#######     data could be your own data or                  ######
#######     simulated example data                          ######
##################################################################
##################################################################

######################################################
####### Methyl-Seq data simulation and analysis ######
######################################################

?methyl.sim	                                                ### check the help file

#### region based estimate
input <- methyl.sim(25,0.7,8)	                              ### generate the simulated data for Methyl-Seq
class(input)                                                ### the input is a matrix, with at least 2 columns
methyl.bayes(input)                                         ### Bayesian region based 
methyl.tpe(input)	                                          ### TPE region based

#### site based 
input <- methyl.sim(25,0.7,1)                               ### generate the simulated data for Methyl-Seq
input <- as.vector(input)
class(input)                                                ### the input is a vector, with at least 2 elements
methyl.bayes.site (input)                                   ### Bayesian site based 
methyl.tpe(input)	                                          ### TPE site based 


################################################
####### RRBS data simulation and analysis ######
################################################

?rrbs.bayes	                 ### check the help file
?rrbs.sim

#### region based estimate
input <- rrbs.sim(25,0.7,8)  ### generate the simulated data for RRBS
class(input)
rrbs.bayes(input)	

#### site based 
input <- rrbs.sim(25,0.7,1)  ### generate the simulated data for RRBS
input <- as.vector(input)
class(input)
rrbs.bayes(input)							




